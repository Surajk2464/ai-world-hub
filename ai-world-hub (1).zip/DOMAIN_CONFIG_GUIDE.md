# Fix ERR_TOO_MANY_REDIRECTS - Domain Configuration Guide

## Problem
You're experiencing redirect loops between `aiworldhub.site` (root) and `www.aiworldhub.site`. This typically happens when:
1. Both domains point to Vercel
2. Vercel redirects root → www (or vice versa) creating a loop
3. DNS records are pointing to Vercel but domain isn't verified in Vercel dashboard

## Your Current DNS Setup
- **A Record** (root): 76.76.21.21 → Points to Vercel
- **CNAME** (www): cname.vercel-dns.com → Points to Vercel

## Solution: Set One Primary Domain

### Step 1: Choose Your Primary Domain
Decide which domain you want as primary:
- **Option A**: `aiworldhub.site` (root domain) as primary → www redirects to root
- **Option B**: `www.aiworldhub.site` as primary → root redirects to www

**Recommended**: Use root domain (`aiworldhub.site`) as primary.

### Step 2: Update DNS Records (in GoDaddy)

#### If using root domain as primary (RECOMMENDED):

1. **Keep A Record** (root domain):
   - Type: A
   - Name: @ (root)
   - Value: 76.76.21.21
   - TTL: 3600

2. **Update CNAME Record** (www subdomain):
   - Type: CNAME
   - Name: www
   - Value: `aiworldhub.site` (points to your root domain)
   - TTL: 3600

   *Alternative: Use `cname.vercel-dns.com` if above doesn't work*

### Step 3: Configure in Vercel Dashboard

1. Go to your Vercel project settings
2. Navigate to **Domains**
3. Add the primary domain: `aiworldhub.site`
4. Verify DNS records when prompted
5. Wait for verification (can take 5-30 minutes)

### Step 4: Handle www Subdomain in next.config.mjs

Add this configuration to automatically redirect www to root:

```javascript
/** @type {import('next').NextConfig} */
const nextConfig = {
  typescript: {
    ignoreBuildErrors: true,
  },
  images: {
    unoptimized: true,
  },
  async redirects() {
    return [
      {
        source: '/:path*',
        has: [
          {
            type: 'host',
            value: 'www.aiworldhub.site',
          },
        ],
        destination: 'https://aiworldhub.site/:path*',
        permanent: true,
      },
    ]
  },
}

export default nextConfig
```

### Step 5: Deploy & Test

1. Commit the `next.config.mjs` changes
2. Deploy to Vercel
3. Wait 2-5 minutes for DNS propagation
4. Test both URLs:
   - `https://aiworldhub.site` → Should load
   - `https://www.aiworldhub.site` → Should redirect to root with 301

## Quick Troubleshooting

| Issue | Solution |
|-------|----------|
| Still getting redirect loop | Clear browser cache (Ctrl+Shift+Del), test in incognito mode |
| DNS not resolving | Wait 10-30 minutes for propagation, check DNS propagation tool |
| Vercel says domain unverified | Add TXT record Vercel provides in GoDaddy |
| www still not redirecting | Ensure next.config.mjs redirect rule is deployed |

## DNS Propagation Check
Check if DNS is working: `nslookup aiworldhub.site` should return 76.76.21.21

## References
- [Vercel Custom Domains Docs](https://vercel.com/docs/concepts/projects/domains)
- [Next.js Redirects](https://nextjs.org/docs/api-reference/next-config.js/redirects)
