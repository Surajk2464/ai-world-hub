'use client';

import { useState, useEffect } from 'react';
import { PremiumNavbar } from '@/components/premium-navbar';
import { PremiumFooter } from '@/components/premium-footer';
import { Search as SearchIcon, ArrowRight } from 'lucide-react';
import Link from 'next/link';
import Image from 'next/image';

export default function SearchPage() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const handleSearch = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setQuery(value);

    if (value.trim().length === 0) {
      setResults([]);
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(`/api/v1/search?q=${encodeURIComponent(value)}`);
      const data = await response.json();
      setResults(data.results || []);
    } catch (error) {
      console.error('[v0] Search error:', error);
      setResults([]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950">
      <PremiumNavbar />

      <section className="py-12 md:py-16">
        <div className="mx-auto max-w-4xl px-4">
          {/* Search Header */}
          <div className="mb-8 text-center">
            <h1 className="mb-4 text-4xl md:text-5xl font-bold gradient-text">
              Search AI Tools
            </h1>
            <p className="text-muted-foreground">
              Find the perfect AI tool for your needs
            </p>
          </div>

          {/* Search Box */}
          <div className="mb-8 rounded-2xl glass-strong border border-cyan-500/30 p-1">
            <div className="flex items-center gap-4 px-6 py-4">
              <SearchIcon className="h-5 w-5 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search by name, category, features..."
                value={query}
                onChange={handleSearch}
                className="flex-1 bg-transparent text-foreground placeholder-muted-foreground focus:outline-none"
                autoFocus
              />
            </div>
          </div>

          {/* Results */}
          <div className="space-y-4">
            {loading && (
              <div className="text-center text-muted-foreground py-8">
                Searching...
              </div>
            )}

            {!loading && results.length === 0 && query.length > 0 && (
              <div className="text-center text-muted-foreground py-8">
                No tools found for "{query}"
              </div>
            )}

            {!loading && results.length === 0 && query.length === 0 && (
              <div className="text-center text-muted-foreground py-8">
                Start typing to search for AI tools
              </div>
            )}

            {results.map((tool: any) => (
              <Link
                key={tool.id}
                href={`/tool/${tool.slug}`}
                className="group flex gap-4 rounded-lg glass p-4 border border-white/5 transition-all hover:border-cyan-500/50 hover:glass-strong"
              >
                {tool.logo && (
                  <div className="h-16 w-16 flex-shrink-0 rounded-lg glass border border-white/10 flex items-center justify-center">
                    <Image
                      src={tool.logo}
                      alt={tool.name}
                      width={64}
                      height={64}
                      className="h-12 w-12 object-contain"
                    />
                  </div>
                )}
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-foreground group-hover:text-cyan-400 transition-colors">
                    {tool.name}
                  </h3>
                  <p className="text-sm text-muted-foreground line-clamp-2">
                    {tool.description}
                  </p>
                  <div className="mt-2 flex flex-wrap gap-2">
                    {tool.tags?.slice(0, 3).map((tag: string) => (
                      <span
                        key={tag}
                        className="inline-block text-xs rounded-full bg-cyan-500/10 border border-cyan-500/20 px-2 py-1 text-cyan-400"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
                <ArrowRight className="h-5 w-5 text-muted-foreground group-hover:text-cyan-400 transition-colors flex-shrink-0 self-center" />
              </Link>
            ))}
          </div>
        </div>
      </section>

      <PremiumFooter />
    </div>
  );
}
