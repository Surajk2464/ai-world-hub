import { createClient } from '@/lib/supabase/server'
import { NextResponse } from 'next/server'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const query = searchParams.get('q')
    const limit = searchParams.get('limit') || '10'

    if (!query) {
      return NextResponse.json(
        { error: 'Search query required' },
        { status: 400 }
      )
    }

    const supabase = await createClient()

    // Search across tool names, descriptions, tags, and features
    const { data, error } = await supabase
      .from('ai_tools')
      .select('id, name, slug, logo, description, category_id, rating')
      .or(
        `name.ilike.%${query}%,description.ilike.%${query}%,tags.cs.{"${query}"},features.cs.{"${query}"}`
      )
      .limit(parseInt(limit))

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json(
      { results: data || [] },
      {
        headers: {
          'Cache-Control': 'public, s-maxage=300, stale-while-revalidate=3600',
        },
      }
    )
  } catch (error) {
    console.error('Error searching tools:', error)
    return NextResponse.json(
      { error: 'Failed to search tools' },
      { status: 500 }
    )
  }
}
