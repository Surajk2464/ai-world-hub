import { createClient } from '@/lib/supabase/server'
import { NextResponse } from 'next/server'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const limit = searchParams.get('limit') || '10'

    const supabase = await createClient()

    const { data: trendingData, error: trendingError } = await supabase
      .from('trending_tools')
      .select('*, tool:ai_tools(id, name, slug, logo, rating, description)')
      .order('score', { ascending: false })
      .limit(parseInt(limit))

    if (trendingError) {
      return NextResponse.json(
        { error: trendingError.message },
        { status: 500 }
      )
    }

    return NextResponse.json(
      { trending: trendingData || [] },
      {
        headers: {
          'Cache-Control': 'public, s-maxage=3600, stale-while-revalidate=86400',
        },
      }
    )
  } catch (error) {
    console.error('Error fetching trending tools:', error)
    return NextResponse.json(
      { error: 'Failed to fetch trending tools' },
      { status: 500 }
    )
  }
}
