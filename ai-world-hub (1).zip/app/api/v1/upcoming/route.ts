import { createClient } from '@/lib/supabase/server'
import { NextResponse } from 'next/server'

export async function GET(request: Request) {
  try {
    const supabase = await createClient()

    const { data, error } = await supabase
      .from('upcoming_tools')
      .select('*')
      .order('launch_date', { ascending: true })
      .limit(10)

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json(
      { upcoming: data || [] },
      {
        headers: {
          'Cache-Control': 'public, s-maxage=3600, stale-while-revalidate=86400',
        },
      }
    )
  } catch (error) {
    console.error('Error fetching upcoming tools:', error)
    return NextResponse.json(
      { error: 'Failed to fetch upcoming tools' },
      { status: 500 }
    )
  }
}
