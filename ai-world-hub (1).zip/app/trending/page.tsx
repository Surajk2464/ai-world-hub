'use client';

import { useState, useEffect } from 'react';
import { PremiumNavbar } from '@/components/premium-navbar';
import { PremiumFooter } from '@/components/premium-footer';
import { Flame, TrendingUp } from 'lucide-react';
import Link from 'next/link';
import Image from 'next/image';
import useSWR from 'swr';

const fetcher = (url: string) => fetch(url).then(res => res.json());

export default function TrendingPage() {
  const { data, isLoading, error } = useSWR('/api/v1/trending', fetcher);

  const trendingTools = data?.tools || [];

  return (
    <div className="min-h-screen bg-slate-950">
      <PremiumNavbar />

      <section className="py-12 md:py-16">
        <div className="mx-auto max-w-7xl px-4">
          {/* Header */}
          <div className="mb-12 text-center">
            <div className="inline-flex items-center gap-2 rounded-full glass px-4 py-2 border border-cyan-500/30 mb-4">
              <Flame className="h-4 w-4 text-orange-400" />
              <span className="text-sm font-medium text-cyan-400">Hot Right Now</span>
            </div>
            <h1 className="mb-4 text-4xl md:text-5xl font-bold gradient-text">
              Trending AI Tools
            </h1>
            <p className="text-lg text-muted-foreground">
              Discover the most popular AI tools this week
            </p>
          </div>

          {/* Trending Grid */}
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {isLoading && (
              <div className="col-span-full text-center py-12 text-muted-foreground">
                Loading trending tools...
              </div>
            )}

            {error && (
              <div className="col-span-full text-center py-12 text-red-400">
                Failed to load trending tools
              </div>
            )}

            {trendingTools.map((tool: any, index: number) => (
              <Link
                key={tool.id}
                href={`/tool/${tool.slug}`}
                className="group flex flex-col rounded-xl glass border border-white/5 p-6 transition-all hover:border-cyan-500/50 hover:glass-strong"
              >
                {/* Rank Badge */}
                <div className="absolute top-4 right-4 h-8 w-8 rounded-full glass-strong border border-cyan-500/30 flex items-center justify-center text-sm font-bold text-cyan-400">
                  #{index + 1}
                </div>

                {/* Logo */}
                {tool.logo && (
                  <div className="mb-4 h-12 w-12 rounded-lg glass border border-white/10 flex items-center justify-center">
                    <Image
                      src={tool.logo}
                      alt={tool.name}
                      width={48}
                      height={48}
                      className="h-10 w-10 object-contain"
                    />
                  </div>
                )}

                {/* Title */}
                <h3 className="mb-2 font-semibold text-foreground group-hover:text-cyan-400 transition-colors">
                  {tool.name}
                </h3>

                {/* Description */}
                <p className="mb-4 text-sm text-muted-foreground line-clamp-2 flex-1">
                  {tool.description}
                </p>

                {/* Trend Info */}
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <TrendingUp className="h-3 w-3 text-green-400" />
                  <span>{tool.trending_score} views this week</span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <PremiumFooter />
    </div>
  );
}
