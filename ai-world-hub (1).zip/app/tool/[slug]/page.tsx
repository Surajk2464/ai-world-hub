import { notFound } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'
import { Metadata } from 'next'
import Image from 'next/image'
import Link from 'next/link'
import { ArrowRight, Star, ExternalLink, Share2, Heart } from 'lucide-react'

type Props = {
  params: { slug: string }
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const supabase = await createClient()
  
  const { data: tool } = await supabase
    .from('ai_tools')
    .select('*')
    .eq('slug', params.slug)
    .single()

  if (!tool) {
    return {
      title: 'Tool Not Found',
      description: 'The AI tool you are looking for does not exist.',
    }
  }

  return {
    title: tool.meta_title || `${tool.name} - AI World Hub`,
    description: tool.meta_description || tool.description,
    keywords: tool.meta_keywords || tool.tags?.join(', '),
    openGraph: {
      title: tool.meta_title || tool.name,
      description: tool.description,
      images: tool.logo ? [{ url: tool.logo, alt: tool.name }] : [],
      type: 'website',
    },
    twitter: {
      card: 'summary_large_image',
      title: tool.name,
      description: tool.description,
      images: tool.logo ? [tool.logo] : [],
    },
  }
}

async function ToolPage({ params }: Props) {
  const supabase = await createClient()

  const { data: tool, error } = await supabase
    .from('ai_tools')
    .select(`
      *,
      category:categories(id, name, slug),
      reviews:tool_reviews(*)
    `)
    .eq('slug', params.slug)
    .single()

  if (error || !tool) {
    notFound()
  }

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Hero Section */}
      <section className="relative border-b border-white/10 py-12 md:py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col gap-8 md:flex-row md:items-start md:gap-12">
            {/* Logo & Basic Info */}
            <div className="flex-shrink-0">
              {tool.logo && (
                <div className="flex h-24 w-24 items-center justify-center rounded-2xl glass-strong border border-cyan-500/30">
                  <Image
                    src={tool.logo}
                    alt={tool.name}
                    width={96}
                    height={96}
                    className="h-20 w-20 object-contain"
                  />
                </div>
              )}
            </div>

            {/* Title & Description */}
            <div className="flex-1">
              <div className="mb-4 flex items-center gap-3">
                {tool.category && (
                  <span className="rounded-full border border-cyan-500/30 bg-cyan-500/10 px-3 py-1 text-xs font-medium text-cyan-400">
                    {tool.category.name}
                  </span>
                )}
                <div className="flex items-center gap-1">
                  <Star className="h-4 w-4 fill-cyan-400 text-cyan-400" />
                  <span className="text-sm font-semibold text-foreground">
                    {tool.rating.toFixed(1)}
                  </span>
                </div>
              </div>

              <h1 className="mb-4 text-4xl md:text-5xl font-bold gradient-text">
                {tool.name}
              </h1>

              <p className="mb-6 text-lg text-muted-foreground">
                {tool.description}
              </p>

              {/* CTA Buttons */}
              <div className="flex flex-wrap gap-4">
                {tool.external_url && (
                  <a
                    href={tool.external_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-cyan-500 to-cyan-600 px-6 py-3 font-medium text-slate-950 transition-all hover:shadow-lg hover:shadow-cyan-500/50 hover:scale-105"
                  >
                    Visit Website
                    <ExternalLink className="h-4 w-4" />
                  </a>
                )}
                <button className="inline-flex items-center gap-2 rounded-full glass-strong px-6 py-3 font-medium text-foreground transition-all hover:border-cyan-500/50 border border-white/10">
                  <Heart className="h-4 w-4" />
                  Save
                </button>
                <button className="inline-flex items-center gap-2 rounded-full glass-strong px-6 py-3 font-medium text-foreground transition-all hover:border-cyan-500/50 border border-white/10">
                  <Share2 className="h-4 w-4" />
                  Share
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-12 md:py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-8 md:grid-cols-3">
            {/* Main Content */}
            <div className="md:col-span-2 space-y-8">
              {/* Features */}
              {tool.features && tool.features.length > 0 && (
                <div>
                  <h2 className="mb-4 text-2xl font-bold text-foreground">
                    Key Features
                  </h2>
                  <div className="grid gap-3">
                    {tool.features.map((feature, index) => (
                      <div
                        key={index}
                        className="flex items-start gap-3 rounded-lg glass p-4 border border-white/5"
                      >
                        <div className="mt-1 h-2 w-2 rounded-full bg-cyan-400 flex-shrink-0" />
                        <p className="text-foreground">{feature}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Screenshots */}
              {tool.screenshots && tool.screenshots.length > 0 && (
                <div>
                  <h2 className="mb-4 text-2xl font-bold text-foreground">
                    Screenshots
                  </h2>
                  <div className="grid gap-4 md:grid-cols-2">
                    {tool.screenshots.map((screenshot, index) => (
                      <div key={index} className="relative rounded-lg overflow-hidden glass border border-white/10">
                        <Image
                          src={screenshot}
                          alt={`${tool.name} screenshot ${index + 1}`}
                          width={600}
                          height={400}
                          className="w-full h-auto"
                        />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Long Description */}
              {tool.long_description && (
                <div>
                  <h2 className="mb-4 text-2xl font-bold text-foreground">
                    About
                  </h2>
                  <div className="text-foreground leading-relaxed whitespace-pre-wrap">
                    {tool.long_description}
                  </div>
                </div>
              )}

              {/* Reviews */}
              {tool.reviews && tool.reviews.length > 0 && (
                <div>
                  <h2 className="mb-4 text-2xl font-bold text-foreground">
                    Reviews
                  </h2>
                  <div className="space-y-4">
                    {tool.reviews.map((review) => (
                      <div key={review.id} className="rounded-lg glass p-6 border border-white/5">
                        <div className="mb-2 flex items-center gap-2">
                          <span className="font-semibold text-foreground">
                            {review.title}
                          </span>
                          <div className="flex items-center gap-1">
                            {Array.from({ length: 5 }).map((_, i) => (
                              <Star
                                key={i}
                                className={`h-3 w-3 ${
                                  i < review.rating
                                    ? 'fill-cyan-400 text-cyan-400'
                                    : 'text-muted-foreground'
                                }`}
                              />
                            ))}
                          </div>
                        </div>
                        {review.content && (
                          <p className="text-sm text-muted-foreground">
                            {review.content}
                          </p>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Pricing Card */}
              <div className="rounded-lg glass-strong p-6 border border-cyan-500/30">
                <h3 className="mb-4 text-lg font-bold text-foreground">
                  Pricing
                </h3>
                <div className="mb-4">
                  <p className="text-3xl font-bold text-cyan-400">
                    {tool.pricing_type === 'free' ? 'Free' : tool.pricing || 'Contact'}
                  </p>
                  {tool.pricing_type && (
                    <p className="text-xs text-muted-foreground capitalize mt-1">
                      {tool.pricing_type}
                    </p>
                  )}
                </div>
              </div>

              {/* Info Card */}
              <div className="rounded-lg glass p-6 border border-white/5">
                <h3 className="mb-4 text-lg font-bold text-foreground">
                  Info
                </h3>
                <div className="space-y-3 text-sm">
                  {tool.launch_date && (
                    <div>
                      <p className="text-muted-foreground">Launch Date</p>
                      <p className="text-foreground">
                        {new Date(tool.launch_date).toLocaleDateString()}
                      </p>
                    </div>
                  )}
                  {tool.tags && tool.tags.length > 0 && (
                    <div>
                      <p className="text-muted-foreground mb-2">Tags</p>
                      <div className="flex flex-wrap gap-2">
                        {tool.tags.slice(0, 5).map((tag) => (
                          <span
                            key={tag}
                            className="rounded-full border border-cyan-500/20 bg-cyan-500/5 px-2 py-1 text-xs text-cyan-400"
                          >
                            {tag}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Related Tools */}
              <div className="rounded-lg glass p-6 border border-white/5">
                <h3 className="mb-4 text-lg font-bold text-foreground">
                  Similar Tools
                </h3>
                <p className="text-sm text-muted-foreground">
                  Coming soon in next update
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* JSON-LD Schema */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'SoftwareApplication',
            name: tool.name,
            description: tool.description,
            url: `${process.env.NEXT_PUBLIC_SITE_URL || 'https://aiworldhub.site'}/tool/${tool.slug}`,
            image: tool.logo,
            aggregateRating: tool.review_count > 0 ? {
              '@type': 'AggregateRating',
              ratingValue: tool.rating,
              reviewCount: tool.review_count,
            } : undefined,
            offers: {
              '@type': 'Offer',
              price: tool.pricing_type === 'free' ? '0' : tool.pricing,
              priceCurrency: 'USD',
            },
          }),
        }}
      />
    </div>
  )
}

export default ToolPage

export async function generateStaticParams() {
  // For now, return empty to prevent build errors with cookies
  // In production, this should fetch from a server-side cache
  return [
    // Prerender top 10 tools
    { slug: 'chatgpt' },
    { slug: 'claude' },
    { slug: 'dalle-3' },
  ]
}

export const revalidate = 86400 // Revalidate every 24 hours

