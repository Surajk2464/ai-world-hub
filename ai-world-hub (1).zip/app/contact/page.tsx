'use client';

import { useState } from 'react';
import { PremiumNavbar } from '@/components/premium-navbar';
import { PremiumFooter } from '@/components/premium-footer';
import { Mail, Send } from 'lucide-react';

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    type: 'feedback',
    message: '',
  });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await fetch('/api/v1/feedback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        setSubmitted(true);
        setFormData({ name: '', email: '', type: 'feedback', message: '' });
        setTimeout(() => setSubmitted(false), 5000);
      }
    } catch (error) {
      console.error('[v0] Submission error:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950">
      <PremiumNavbar />

      <section className="py-12 md:py-16">
        <div className="mx-auto max-w-2xl px-4">
          {/* Header */}
          <div className="mb-8 text-center">
            <div className="inline-flex items-center gap-2 rounded-full glass px-4 py-2 border border-cyan-500/30 mb-4">
              <Mail className="h-4 w-4 text-cyan-400" />
              <span className="text-sm font-medium text-cyan-400">Get in Touch</span>
            </div>
            <h1 className="mb-4 text-4xl md:text-5xl font-bold gradient-text">
              Contact Us
            </h1>
            <p className="text-lg text-muted-foreground">
              Report a broken tool, suggest a new AI tool, or send feedback
            </p>
          </div>

          {/* Form */}
          <div className="rounded-2xl glass-strong border border-cyan-500/30 p-8">
            {submitted && (
              <div className="mb-6 rounded-lg bg-green-500/10 border border-green-500/30 p-4 text-green-400">
                Thank you for your feedback! We'll review it shortly.
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Name */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Name
                </label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="Your name"
                  className="w-full rounded-lg glass bg-white/5 border border-white/10 px-4 py-3 text-foreground placeholder-muted-foreground focus:border-cyan-500/50 focus:outline-none transition-colors"
                  required
                />
              </div>

              {/* Email */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Email
                </label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="your@email.com"
                  className="w-full rounded-lg glass bg-white/5 border border-white/10 px-4 py-3 text-foreground placeholder-muted-foreground focus:border-cyan-500/50 focus:outline-none transition-colors"
                  required
                />
              </div>

              {/* Type */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Feedback Type
                </label>
                <select
                  name="type"
                  value={formData.type}
                  onChange={handleChange}
                  className="w-full rounded-lg glass bg-white/5 border border-white/10 px-4 py-3 text-foreground focus:border-cyan-500/50 focus:outline-none transition-colors"
                >
                  <option value="feedback">General Feedback</option>
                  <option value="bug">Report Broken Tool</option>
                  <option value="suggestion">Suggest AI Tool</option>
                  <option value="other">Other</option>
                </select>
              </div>

              {/* Message */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Message
                </label>
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  placeholder="Your message..."
                  rows={6}
                  className="w-full rounded-lg glass bg-white/5 border border-white/10 px-4 py-3 text-foreground placeholder-muted-foreground focus:border-cyan-500/50 focus:outline-none transition-colors resize-none"
                  required
                />
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={loading}
                className="w-full rounded-lg bg-gradient-to-r from-cyan-500 to-cyan-600 px-6 py-3 font-medium text-slate-950 transition-all hover:shadow-lg hover:shadow-cyan-500/50 hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {loading ? 'Sending...' : (
                  <>
                    <Send className="h-4 w-4" />
                    Send Message
                  </>
                )}
              </button>
            </form>
          </div>
        </div>
      </section>

      <PremiumFooter />
    </div>
  );
}
