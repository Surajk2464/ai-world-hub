'use client';

import { PremiumNavbar } from '@/components/premium-navbar';
import { PremiumFooter } from '@/components/premium-footer';
import { Calendar, User } from 'lucide-react';
import Link from 'next/link';
import Image from 'next/image';
import useSWR from 'swr';

const fetcher = (url: string) => fetch(url).then(res => res.json());

export default function BlogPage() {
  const { data, isLoading, error } = useSWR('/api/v1/news', fetcher);

  const articles = data?.news || [];

  return (
    <div className="min-h-screen bg-slate-950">
      <PremiumNavbar />

      <section className="py-12 md:py-16">
        <div className="mx-auto max-w-6xl px-4">
          {/* Header */}
          <div className="mb-12">
            <h1 className="mb-4 text-4xl md:text-5xl font-bold gradient-text">
              AI News & Blog
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl">
              Stay updated with the latest trends in artificial intelligence, new tool releases, and industry insights
            </p>
          </div>

          {/* Articles Grid */}
          {isLoading && (
            <div className="text-center py-12 text-muted-foreground">
              Loading articles...
            </div>
          )}

          {error && (
            <div className="text-center py-12 text-red-400">
              Failed to load articles
            </div>
          )}

          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            {articles.map((article: any) => (
              <article
                key={article.id}
                className="group flex flex-col rounded-xl glass border border-white/5 overflow-hidden transition-all hover:border-cyan-500/50 hover:glass-strong"
              >
                {/* Image */}
                {article.image && (
                  <div className="relative h-48 w-full overflow-hidden bg-gradient-to-br from-slate-800 to-slate-900">
                    <Image
                      src={article.image}
                      alt={article.title}
                      width={400}
                      height={300}
                      className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                )}

                {/* Content */}
                <div className="flex flex-1 flex-col p-6">
                  {/* Badge */}
                  {article.is_breaking && (
                    <div className="mb-3 inline-flex w-fit rounded-full bg-red-500/20 px-3 py-1 text-xs font-semibold text-red-400 border border-red-500/30">
                      Breaking
                    </div>
                  )}

                  {/* Title */}
                  <h3 className="mb-2 text-xl font-bold text-foreground group-hover:text-cyan-400 transition-colors line-clamp-2">
                    {article.title}
                  </h3>

                  {/* Excerpt */}
                  <p className="mb-4 text-sm text-muted-foreground line-clamp-3 flex-1">
                    {article.excerpt || article.content?.substring(0, 150)}
                  </p>

                  {/* Meta */}
                  <div className="flex items-center gap-4 text-xs text-muted-foreground border-t border-white/5 pt-4">
                    <div className="flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      {new Date(article.published_at).toLocaleDateString()}
                    </div>
                  </div>
                </div>
              </article>
            ))}
          </div>

          {articles.length === 0 && !isLoading && (
            <div className="text-center py-12 text-muted-foreground">
              No articles published yet
            </div>
          )}
        </div>
      </section>

      <PremiumFooter />
    </div>
  );
}
