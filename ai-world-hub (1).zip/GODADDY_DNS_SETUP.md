## GoDaddy DNS Configuration for aiworldhub.site - Vercel Verification

This guide provides the exact DNS records you need to add in GoDaddy to verify your domain with Vercel.

---

### IMPORTANT: Root Domain vs. WWW

Your Vercel Dashboard is showing records for domain verification. Follow these steps exactly:

---

## Step 1: Navigate to GoDaddy DNS Settings

1. Go to [https://www.godaddy.com](https://www.godaddy.com)
2. Sign in to your account
3. Click on **Products** or **My Products**
4. Find **aiworldhub.site** and click the **DNS** button next to it
5. You'll see the DNS Management page with existing records

---

## Step 2: Add/Update the DNS Records for Vercel

Vercel requires these records to be added to verify your domain:

### A Record (for root domain - aiworldhub.site)

| Field | Value |
|-------|-------|
| **Type** | A |
| **Name** | @ (or leave blank - represents root domain) |
| **Points to (Value)** | `216.198.79.1` |
| **TTL** | 3600 (or Auto) |

**Action:** Either update your existing A record (76.76.21.21) to this new value, OR add as a new record.

---

### CNAME Record (for www subdomain)

| Field | Value |
|-------|-------|
| **Type** | CNAME |
| **Name** | www |
| **Points to (Value)** | `cname.vercel-dns.com` |
| **TTL** | 3600 (or Auto) |

**Action:** Update the existing CNAME record if present, or add new if not.

---

### TXT Record (for domain verification - OPTIONAL but recommended)

If Vercel shows a TXT record requirement, add:

| Field | Value |
|-------|-------|
| **Type** | TXT |
| **Name** | _vercel (or the specific subdomain Vercel shows) |
| **Value** | (Check your Vercel Dashboard for the exact verification token) |
| **TTL** | 3600 (or Auto) |

**Note:** Vercel typically provides a specific TXT record value in the dashboard. Copy it exactly.

---

## Step 3: Verify in Vercel Dashboard

1. After adding records in GoDaddy, go to your **Vercel Project Settings**
2. Navigate to **Domains**
3. Find **aiworldhub.site**
4. Click **Verify DNS Configuration** or wait for automatic verification (usually 5-30 minutes)
5. Status should change from "Verification Needed" to "Valid Configuration"

---

## Step 4: Common Issues & Troubleshooting

### If verification still fails:

1. **Check TTL**: Vercel records may take up to 48 hours to fully propagate (usually faster)
2. **Verify exact values**: Copy-paste directly from Vercel Dashboard to avoid typos
3. **Remove old records**: If you have conflicting A records pointing to 76.76.21.21, consider removing them
4. **Clear browser cache**: Hard refresh (Ctrl+Shift+R on Windows, Cmd+Shift+R on Mac)
5. **Wait and retry**: DNS changes propagate gradually; wait 10 minutes and click "Verify" again

---

## Summary of Changes

| Record Type | Name | Current Value | New Value |
|-------------|------|---------------|-----------|
| A | @ (root) | 76.76.21.21 | 216.198.79.1 |
| CNAME | www | cname.vercel-dns.com | cname.vercel-dns.com (same) |

---

## Next.js Redirect Configuration (Already Applied)

Your `next.config.mjs` has already been updated to redirect `www.aiworldhub.site` → `aiworldhub.site`, so no application changes needed.

---

## Questions?

If the verification still shows errors after 30 minutes:
- Double-check all record values character-by-character
- Check your Vercel Dashboard for any error messages
- Visit [Vercel DNS Documentation](https://vercel.com/docs/projects/domains/add-a-domain) for additional help
