// Types for all database tables
export type Category = {
  id: string
  name: string
  slug: string
  description?: string
  icon?: string
  color?: string
  created_at: string
}

export type AiTool = {
  id: string
  name: string
  slug: string
  description: string
  long_description?: string
  logo?: string
  category_id?: string
  external_url?: string
  pricing?: string
  pricing_type?: string
  features?: string[]
  tags?: string[]
  screenshots?: string[]
  youtube_videos?: string[]
  rating: number
  review_count: number
  launch_date?: string
  trending_score: number
  meta_title?: string
  meta_description?: string
  meta_keywords?: string
  is_featured: boolean
  created_at: string
  updated_at: string
  category?: Category
}

export type TrendingTool = {
  id: string
  tool_id: string
  score: number
  reason?: string
  updated_at: string
  tool?: AiTool
}

export type UpcomingTool = {
  id: string
  name: string
  slug: string
  description?: string
  logo?: string
  launch_date?: string
  waitlist_count: number
  created_at: string
}

export type AiNews = {
  id: string
  title: string
  slug: string
  content: string
  excerpt?: string
  image?: string
  is_breaking: boolean
  category?: string
  published_at: string
  created_at: string
}

export type Blog = {
  id: string
  title: string
  slug: string
  content: string
  excerpt?: string
  featured_image?: string
  author?: string
  tags?: string[]
  meta_title?: string
  meta_description?: string
  published_at: string
  created_at: string
}

export type ToolReview = {
  id: string
  tool_id: string
  title: string
  content?: string
  rating: number
  created_at: string
}

export type Feedback = {
  id: string
  email?: string
  name?: string
  message: string
  type?: string
  created_at: string
}
