export type Category =
  | "All"
  | "Writing"
  | "Design"
  | "Research"
  | "Video"
  | "Coding"
  | "Audio"
  | "Productivity"
  | "Marketing"
  | "Image";

export interface AITool {
  id: string;
  slug: string;
  name: string;
  description: string;
  shortDescription: string;
  logo: string;
  category: Category;
  pricing: "Free" | "Freemium" | "Paid";
  priceDetails?: string;
  features: string[];
  website: string;
  rating: number;
  useCases: string[];
  pros: string[];
  cons: string[];
  howItWorks: string;
  monetization: string[];
  fullGuide?: string;
}

export interface VideoShowcase {
  id: string;
  title: string;
  subtitle: string;
  toolSlug?: string;
  thumbnailUrl?: string;
  videoUrl?: string;
}

export interface NewsItem {
  id: string;
  headline: string;
  category: string;
  timestamp: string;
  isBreaking?: boolean;
}

export const categories: Category[] = [
  "All",
  "Writing",
  "Design",
  "Research",
  "Video",
  "Coding",
  "Audio",
  "Productivity",
  "Marketing",
  "Image",
];

// Dynamic showcase data - ready for API injection
export const videoShowcases: VideoShowcase[] = [
  {
    id: "1",
    title: "Next-Gen AI Writing",
    subtitle: "Transform your content workflow with intelligent automation",
    toolSlug: "chatgpt",
  },
  {
    id: "2",
    title: "Visual AI Revolution",
    subtitle: "Create stunning visuals in seconds with text-to-image",
    toolSlug: "midjourney",
  },
  {
    id: "3",
    title: "Code Faster, Ship More",
    subtitle: "AI pair programming that understands your codebase",
    toolSlug: "github-copilot",
  },
];

// Live news ticker data - ready for real-time API
export const newsItems: NewsItem[] = [
  { id: "1", headline: "GPT-5 Training Complete: New benchmarks shatter records", category: "LLM", timestamp: "2m ago", isBreaking: true },
  { id: "2", headline: "Sora v2 API now available for enterprise developers", category: "Video", timestamp: "15m ago" },
  { id: "3", headline: "Claude 4 introduces 1M token context window", category: "LLM", timestamp: "1h ago" },
  { id: "4", headline: "Midjourney launches real-time collaborative editing", category: "Image", timestamp: "2h ago" },
  { id: "5", headline: "Google DeepMind announces Gemini Ultra 2.0", category: "AI", timestamp: "3h ago", isBreaking: true },
  { id: "6", headline: "Runway Gen-3 Alpha achieves photorealistic video", category: "Video", timestamp: "4h ago" },
  { id: "7", headline: "OpenAI Codex 2.0 understands full repositories", category: "Coding", timestamp: "5h ago" },
  { id: "8", headline: "ElevenLabs achieves indistinguishable voice cloning", category: "Audio", timestamp: "6h ago" },
];

export const aiTools: AITool[] = [
  {
    id: "1",
    slug: "chatgpt",
    name: "ChatGPT",
    description: "ChatGPT is a powerful AI assistant developed by OpenAI that can engage in natural conversations, answer questions, help with writing tasks, coding, analysis, and much more. It uses advanced language models to understand context and provide helpful, accurate responses.",
    shortDescription: "AI-powered conversational assistant for writing, coding, and problem-solving",
    logo: "🤖",
    category: "Writing",
    pricing: "Freemium",
    priceDetails: "Free tier available. Plus: $20/mo, Team: $25/user/mo, Enterprise: Custom",
    features: ["Natural Conversations", "Code Generation", "Writing Assistance", "Multi-language Support", "Plugin Ecosystem", "Custom GPTs"],
    website: "https://chat.openai.com",
    rating: 4.8,
    useCases: ["Content writing", "Code debugging", "Research assistance", "Language translation", "Creative brainstorming"],
    pros: ["Versatile capabilities", "User-friendly interface", "Continuous improvements", "Free tier available"],
    cons: ["Can produce incorrect information", "Limited knowledge cutoff", "Response limits on free tier"],
    howItWorks: "ChatGPT uses transformer-based neural networks trained on vast amounts of text data. It processes your input, understands context, and generates human-like responses by predicting the most likely next words based on patterns learned during training. The model uses attention mechanisms to focus on relevant parts of your conversation history, enabling contextual understanding across long dialogues.",
    monetization: ["Content creation services", "Customer support automation", "Educational tutoring", "Code review services", "Translation services", "Build and sell Custom GPTs", "API integration consulting"],
    fullGuide: "ChatGPT represents a fundamental shift in how humans interact with AI. Built on the GPT-4 architecture, it excels at understanding nuanced requests and generating contextually appropriate responses. The system processes text through multiple transformer layers, each refining the understanding and output quality. For optimal results, provide clear context, specify the desired format, and iterate on responses. Professional users leverage system prompts to maintain consistent output styles across sessions.",
  },
  {
    id: "2",
    slug: "midjourney",
    name: "Midjourney",
    description: "Midjourney is a revolutionary AI art generator that creates stunning, unique images from text descriptions. It excels at producing artistic, stylized visuals perfect for creative projects, marketing materials, and artistic exploration.",
    shortDescription: "AI art generator creating stunning images from text prompts",
    logo: "🎨",
    category: "Image",
    pricing: "Paid",
    priceDetails: "Basic: $10/mo, Standard: $30/mo, Pro: $60/mo, Mega: $120/mo",
    features: ["Text-to-Image", "Artistic Styles", "High Resolution", "Image Variations", "Style Tuner", "Pan & Zoom"],
    website: "https://midjourney.com",
    rating: 4.9,
    useCases: ["Digital art creation", "Marketing visuals", "Book covers", "Game concept art", "Social media content"],
    pros: ["Exceptional art quality", "Unique artistic style", "Active community", "Regular updates"],
    cons: ["Subscription required", "Discord-based interface", "Learning curve for prompts"],
    howItWorks: "Midjourney uses diffusion models that start with random noise and gradually refine it into coherent images based on your text prompts. The AI has been trained on millions of images to understand artistic styles, compositions, and visual concepts. It interprets your text through CLIP encoding, mapping words to visual features, then iteratively denoises the image while being guided by your description.",
    monetization: ["Print-on-demand products", "Stock image creation", "Client artwork commissions", "NFT creation", "Social media management", "Brand asset packages", "Book cover design services"],
    fullGuide: "Mastering Midjourney requires understanding its unique prompt syntax and artistic biases. The model responds exceptionally well to artistic references, lighting descriptions, and compositional directions. Use aspect ratios strategically for different platforms. The --stylize parameter controls how strongly the AI interprets your prompt artistically. Lower values produce more literal interpretations; higher values allow more creative freedom. Experiment with --chaos for unexpected variations.",
  },
  {
    id: "3",
    slug: "github-copilot",
    name: "GitHub Copilot",
    description: "GitHub Copilot is an AI-powered code completion tool that helps developers write code faster and with fewer errors. It suggests entire lines or blocks of code as you type, learning from the context of your project.",
    shortDescription: "AI pair programmer that helps you write code faster",
    logo: "💻",
    category: "Coding",
    pricing: "Paid",
    priceDetails: "Individual: $10/mo, Business: $19/user/mo, Enterprise: $39/user/mo",
    features: ["Code Completion", "Multi-language", "IDE Integration", "Context Awareness", "Chat Interface", "CLI Integration"],
    website: "https://github.com/features/copilot",
    rating: 4.7,
    useCases: ["Rapid prototyping", "Learning new languages", "Boilerplate generation", "Test writing", "Documentation"],
    pros: ["Speeds up coding", "Learns from context", "Multiple IDE support", "High-quality suggestions"],
    cons: ["Subscription cost", "May suggest incorrect code", "Privacy concerns for proprietary code"],
    howItWorks: "Copilot is powered by OpenAI Codex, trained on billions of lines of public code. It analyzes your current file, comments, and coding patterns to predict and suggest relevant code completions in real-time. The model considers file context, import statements, function signatures, and even variable naming conventions to provide contextually appropriate suggestions.",
    monetization: ["Freelance development", "Building MVPs faster", "Code consulting", "Tutorial creation", "Open source contributions", "Technical writing", "Code review services"],
    fullGuide: "GitHub Copilot transforms the development workflow by understanding not just syntax but intent. Write descriptive comments before functions to guide generation. Use it for boilerplate, tests, and documentation where patterns are predictable. For complex logic, review suggestions carefully. The chat feature enables conversational debugging and explanation of unfamiliar codebases.",
  },
  {
    id: "4",
    slug: "jasper",
    name: "Jasper",
    description: "Jasper is an AI writing assistant designed specifically for marketing and business content. It helps create high-converting copy for ads, emails, blogs, and social media with brand voice consistency.",
    shortDescription: "AI copywriting assistant for marketing and business content",
    logo: "✍️",
    category: "Marketing",
    pricing: "Paid",
    priceDetails: "Creator: $39/mo, Pro: $59/mo, Business: Custom pricing",
    features: ["Marketing Templates", "Brand Voice", "SEO Integration", "Team Collaboration", "Campaign Management", "Performance Analytics"],
    website: "https://jasper.ai",
    rating: 4.6,
    useCases: ["Ad copy", "Email marketing", "Blog posts", "Product descriptions", "Social media"],
    pros: ["Marketing-focused", "Brand voice training", "Template library", "Good for teams"],
    cons: ["Premium pricing", "Learning curve", "May need editing"],
    howItWorks: "Jasper uses advanced language models fine-tuned for marketing content. It incorporates your brand guidelines, target audience data, and marketing best practices to generate persuasive, on-brand content. The system learns from your edits and feedback to improve brand voice matching over time.",
    monetization: ["Copywriting agency", "Content marketing services", "Social media management", "Email marketing services", "Ad campaign management", "Brand consulting", "Marketing automation setup"],
    fullGuide: "Jasper excels when properly configured with brand voice profiles. Train it on your best-performing content to establish patterns. Use the campaign feature to maintain consistency across multi-channel initiatives. The SEO mode integrates with Surfer for optimized blog content. Templates accelerate production but custom workflows often yield better results for unique brand voices.",
  },
  {
    id: "5",
    slug: "runway",
    name: "Runway",
    description: "Runway is a creative AI platform specializing in video generation and editing. It offers tools for text-to-video, image-to-video, and powerful video editing features powered by machine learning.",
    shortDescription: "AI-powered video creation and editing platform",
    logo: "🎬",
    category: "Video",
    pricing: "Freemium",
    priceDetails: "Free: 125 credits, Standard: $12/mo, Pro: $28/mo, Unlimited: $76/mo",
    features: ["Text-to-Video", "Video Editing", "Green Screen", "Motion Tracking", "Gen-3 Alpha", "Multi-Motion Brush"],
    website: "https://runway.ml",
    rating: 4.5,
    useCases: ["Video content creation", "Film production", "Social media videos", "Advertising", "Music videos"],
    pros: ["Cutting-edge AI video", "Web-based", "Creative freedom", "Regular new features"],
    cons: ["Credit-based system", "Generation time", "Quality varies"],
    howItWorks: "Runway combines multiple AI models including Gen-3 for video generation. It uses diffusion models and neural networks to understand text/image inputs and generate or manipulate video content frame by frame. The platform maintains temporal consistency through specialized architectures that understand motion and physics.",
    monetization: ["Video production services", "YouTube content creation", "Social media video agency", "Advertising production", "Music video creation", "Film VFX services", "Tutorial production"],
    fullGuide: "Runway Gen-3 represents the current state-of-the-art in AI video generation. For best results, start with strong reference images or detailed text prompts describing motion, not just appearance. Use the Multi-Motion Brush to control different elements independently. The platform excels at atmospheric shots and abstract sequences; photorealistic human faces remain challenging.",
  },
  {
    id: "6",
    slug: "notion-ai",
    name: "Notion AI",
    description: "Notion AI enhances the popular Notion workspace with AI capabilities for writing, summarizing, brainstorming, and organizing information within your existing workflow.",
    shortDescription: "AI assistant integrated into Notion workspace",
    logo: "📝",
    category: "Productivity",
    pricing: "Freemium",
    priceDetails: "Free: Limited, Plus: $8/mo, Business: $15/mo, AI add-on: $8/member/mo",
    features: ["Writing Assistant", "Summarization", "Translation", "Action Items", "Q&A", "Database Autofill"],
    website: "https://notion.so/product/ai",
    rating: 4.4,
    useCases: ["Note enhancement", "Meeting summaries", "Content drafting", "Project planning", "Knowledge management"],
    pros: ["Seamless integration", "Context-aware", "Multiple AI functions", "Team friendly"],
    cons: ["Requires Notion", "Additional cost", "Limited customization"],
    howItWorks: "Notion AI is built into the Notion editor, using GPT models to understand your workspace context. It can access your notes, databases, and documents to provide relevant, context-aware assistance. The integration enables AI to reference your existing content when generating or answering questions.",
    monetization: ["Virtual assistance", "Content organization services", "Documentation consulting", "Workflow optimization", "Team productivity coaching", "Second brain setup services", "Template creation"],
    fullGuide: "Notion AI transforms knowledge management by understanding relationships between your documents. Use it to maintain wikis, generate meeting agendas from notes, and extract insights from large document collections. The Q&A feature across your workspace enables team members to find information without manual searching. Database autofill accelerates data entry for consistent record-keeping.",
  },
  {
    id: "7",
    slug: "perplexity",
    name: "Perplexity AI",
    description: "Perplexity is an AI-powered research assistant that provides accurate, cited answers to your questions by searching and synthesizing information from across the web in real-time.",
    shortDescription: "AI research assistant with real-time web search",
    logo: "🔍",
    category: "Research",
    pricing: "Freemium",
    priceDetails: "Free: Unlimited basic, Pro: $20/mo with GPT-4 and Claude",
    features: ["Real-time Search", "Source Citations", "Follow-up Questions", "Pro Search", "File Analysis", "Collections"],
    website: "https://perplexity.ai",
    rating: 4.7,
    useCases: ["Academic research", "Fact-checking", "Market research", "News analysis", "Technical learning"],
    pros: ["Accurate citations", "Up-to-date information", "Clean interface", "Free tier"],
    cons: ["Limited deep analysis", "Occasional source issues", "Pro features costly"],
    howItWorks: "Perplexity combines large language models with real-time web search. When you ask a question, it searches the internet, synthesizes relevant information, and generates a comprehensive answer with citations. Pro Search uses multiple queries and deeper analysis for complex topics.",
    monetization: ["Research services", "Content fact-checking", "Academic assistance", "Market research reports", "Technical documentation", "Competitor analysis", "Due diligence research"],
    fullGuide: "Perplexity bridges the gap between search engines and AI assistants. Use Pro Search for multi-step research questions that require synthesis across sources. Collections enable organizing research by project. The file analysis feature processes PDFs and documents for Q&A. For academic work, the citation system provides verifiable sources essential for credibility.",
  },
  {
    id: "8",
    slug: "elevenlabs",
    name: "ElevenLabs",
    description: "ElevenLabs is a leading AI voice synthesis platform offering realistic text-to-speech, voice cloning, and audio generation with emotional range and natural intonation.",
    shortDescription: "AI voice synthesis and cloning platform",
    logo: "🎙️",
    category: "Audio",
    pricing: "Freemium",
    priceDetails: "Free: 10k chars/mo, Starter: $5/mo, Creator: $22/mo, Pro: $99/mo",
    features: ["Text-to-Speech", "Voice Cloning", "Multiple Languages", "Emotional Range", "Projects", "Sound Effects"],
    website: "https://elevenlabs.io",
    rating: 4.8,
    useCases: ["Audiobook production", "Video narration", "Podcast creation", "Accessibility", "Gaming"],
    pros: ["Exceptional quality", "Voice cloning", "Many languages", "API access"],
    cons: ["Usage limits", "Ethical concerns", "Premium for best features"],
    howItWorks: "ElevenLabs uses deep learning models trained on speech data to generate highly realistic voices. Their proprietary algorithms capture nuances like emotion, pace, and intonation for natural-sounding output. Voice cloning requires minimal samples to create custom voices that match the original speaker.",
    monetization: ["Audiobook narration", "Voice-over services", "Podcast production", "E-learning content", "Accessibility services", "Video dubbing", "Custom voice creation"],
    fullGuide: "ElevenLabs achieves the most natural AI voices available. For voice cloning, provide clean audio samples with varied intonation. The Projects feature enables long-form audio with consistent voice and pacing. Use SSML tags for fine-grained control over pronunciation and pauses. The API integrates easily into applications for real-time voice generation.",
  },
  {
    id: "9",
    slug: "figma-ai",
    name: "Figma AI",
    description: "Figma AI brings intelligent design assistance to the popular design platform, helping with auto-layout, component suggestions, image generation, and design system management.",
    shortDescription: "AI-powered design assistant in Figma",
    logo: "🎯",
    category: "Design",
    pricing: "Freemium",
    priceDetails: "Free: Limited, Professional: $15/editor/mo, Organization: $45/editor/mo",
    features: ["Auto-layout", "Component Suggestions", "Image Generation", "Design Systems", "Prototype Generation", "Asset Search"],
    website: "https://figma.com",
    rating: 4.5,
    useCases: ["UI design", "Prototyping", "Design systems", "Wireframing", "Component creation"],
    pros: ["Native integration", "Speeds up workflow", "Smart suggestions", "Team collaboration"],
    cons: ["Limited features currently", "Figma required", "Beta features"],
    howItWorks: "Figma AI analyzes your design patterns, components, and style guides to provide contextual suggestions. It uses computer vision and language models to understand design intent and automate repetitive tasks. The system learns from your team's design system to maintain consistency.",
    monetization: ["UI/UX design services", "Design system consulting", "Rapid prototyping", "Design training", "Template creation", "Component library development", "Design audit services"],
    fullGuide: "Figma AI accelerates the design-to-development pipeline. Use it for initial layout generation, then refine manually. The AI understands component variants and suggests appropriate usage based on context. Auto-layout suggestions maintain responsive design principles. For design systems, AI ensures consistency by flagging deviations from established patterns.",
  },
  {
    id: "10",
    slug: "descript",
    name: "Descript",
    description: "Descript is an all-in-one audio and video editing platform that uses AI to enable text-based editing, automatic transcription, and powerful features like Overdub for voice synthesis.",
    shortDescription: "AI-powered audio and video editing through text",
    logo: "🎧",
    category: "Audio",
    pricing: "Freemium",
    priceDetails: "Free: 1hr transcription, Creator: $12/mo, Pro: $24/mo, Enterprise: Custom",
    features: ["Text-based Editing", "Transcription", "Screen Recording", "Overdub Voice", "Studio Sound", "Eye Contact"],
    website: "https://descript.com",
    rating: 4.6,
    useCases: ["Podcast editing", "Video creation", "Transcription", "Course creation", "Social clips"],
    pros: ["Intuitive editing", "Accurate transcription", "All-in-one solution", "Collaboration"],
    cons: ["Processing time", "Learning curve", "Export limits on free tier"],
    howItWorks: "Descript uses AI to transcribe your audio/video and links the text to the media timeline. Editing the text edits the media, making it as easy as using a word processor. Overdub uses your voice samples to generate synthetic speech matching your voice for corrections.",
    monetization: ["Podcast production", "Video editing services", "Transcription services", "Course creation", "Content repurposing", "Corporate video production", "Social media clips"],
    fullGuide: "Descript revolutionizes editing by treating media as text. Record or import content, then edit by deleting, rearranging, or correcting words in the transcript. Overdub requires training with your voice samples but enables seamless corrections without re-recording. Studio Sound removes background noise and enhances audio quality automatically. The Sequences feature enables multi-track video editing.",
  },
  {
    id: "11",
    slug: "claude",
    name: "Claude",
    description: "Claude is Anthropic's AI assistant known for its helpfulness, harmlessness, and honesty. It excels at analysis, writing, coding, and thoughtful conversation with strong safety measures.",
    shortDescription: "AI assistant focused on helpfulness and safety",
    logo: "🧠",
    category: "Writing",
    pricing: "Freemium",
    priceDetails: "Free: Limited, Pro: $20/mo, Team: $25/user/mo, Enterprise: Custom",
    features: ["Long Context", "Analysis", "Coding Help", "Document Processing", "Artifacts", "Projects"],
    website: "https://claude.ai",
    rating: 4.7,
    useCases: ["Document analysis", "Research assistance", "Code review", "Writing help", "Complex reasoning"],
    pros: ["Long context window", "Thoughtful responses", "Strong reasoning", "Safety focused"],
    cons: ["Limited availability", "Fewer integrations", "No image generation"],
    howItWorks: "Claude uses Constitutional AI training, where the model is trained to be helpful while following ethical principles. It can process very long documents and maintain context across lengthy conversations. The model excels at nuanced analysis and provides balanced perspectives on complex topics.",
    monetization: ["Research consulting", "Document analysis services", "Code review services", "Writing assistance", "Legal document analysis", "Strategic planning support", "Technical documentation"],
    fullGuide: "Claude excels at tasks requiring nuanced understanding and ethical consideration. The extended context window enables processing entire codebases or lengthy documents. Use Artifacts for code, visualizations, and documents that Claude creates. Projects enable persistent context across conversations. Claude's reasoning is particularly strong for comparative analysis and identifying potential issues in plans or documents.",
  },
  {
    id: "12",
    slug: "stable-diffusion",
    name: "Stable Diffusion",
    description: "Stable Diffusion is an open-source AI image generation model that creates detailed images from text descriptions. It can be run locally and has a vast ecosystem of tools and models.",
    shortDescription: "Open-source AI image generation model",
    logo: "🖼️",
    category: "Image",
    pricing: "Free",
    priceDetails: "Free: Self-hosted, Cloud services vary by provider",
    features: ["Text-to-Image", "Image-to-Image", "Inpainting", "ControlNet", "LoRA Training", "Local Deployment"],
    website: "https://stability.ai",
    rating: 4.6,
    useCases: ["Art creation", "Concept design", "Photo editing", "Game assets", "Custom workflows"],
    pros: ["Free & open source", "Run locally", "Highly customizable", "Active community"],
    cons: ["Technical setup", "Hardware requirements", "Quality varies by model"],
    howItWorks: "Stable Diffusion uses latent diffusion, working in a compressed space to efficiently generate images. It starts with noise and iteratively denoises it guided by your text prompt, which is encoded by CLIP. The latent space approach enables running on consumer GPUs while maintaining quality.",
    monetization: ["Custom model training", "Art generation services", "Game asset creation", "Photo editing services", "AI art consulting", "LoRA training services", "Workflow automation"],
    fullGuide: "Stable Diffusion's open nature enables unprecedented customization. Use ComfyUI or Automatic1111 for advanced workflows. LoRA models enable fine-tuning on specific styles or subjects with minimal data. ControlNet provides precise control over composition through depth maps, poses, and edges. For production use, optimize with quantization and batching for efficient generation.",
  },
];

export function getToolsByCategory(category: Category): AITool[] {
  if (category === "All") {
    return aiTools;
  }
  return aiTools.filter((tool) => tool.category === category);
}

export function getToolBySlug(slug: string): AITool | undefined {
  return aiTools.find((tool) => tool.slug === slug);
}

export function getRelatedTools(tool: AITool, limit: number = 4): AITool[] {
  return aiTools
    .filter((t) => t.category === tool.category && t.id !== tool.id)
    .slice(0, limit);
}

export function getToolsBySearch(query: string): AITool[] {
  const lowerQuery = query.toLowerCase();
  return aiTools.filter(
    (tool) =>
      tool.name.toLowerCase().includes(lowerQuery) ||
      tool.shortDescription.toLowerCase().includes(lowerQuery) ||
      tool.description.toLowerCase().includes(lowerQuery) ||
      tool.features.some((f) => f.toLowerCase().includes(lowerQuery)) ||
      tool.category.toLowerCase().includes(lowerQuery)
  );
}
