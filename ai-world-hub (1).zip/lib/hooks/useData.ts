import useSWR from 'swr'
import { AiTool, Category, TrendingTool, AiNews, UpcomingTool } from '@/lib/database.types'

const fetcher = (url: string) => fetch(url).then(r => r.json())

export function useTools(category?: string, limit = 50, offset = 0) {
  const query = new URLSearchParams()
  if (category && category !== 'All') query.append('category', category)
  query.append('limit', limit.toString())
  query.append('offset', offset.toString())

  const { data, error, isLoading } = useSWR<{
    data: AiTool[]
    count: number
    total: number
  }>(
    `/api/v1/tools?${query}`,
    fetcher,
    { revalidateOnFocus: false }
  )

  return {
    tools: data?.data || [],
    count: data?.count || 0,
    total: data?.total || 0,
    isLoading,
    error,
  }
}

export function useTool(slug: string) {
  const { data, error, isLoading } = useSWR<AiTool>(
    slug ? `/api/v1/tools/${slug}` : null,
    fetcher,
    { revalidateOnFocus: false }
  )

  return {
    tool: data || null,
    isLoading,
    error,
  }
}

export function useSearch(query: string, limit = 10) {
  const { data, error, isLoading } = useSWR<{ results: AiTool[] }>(
    query ? `/api/v1/search?q=${encodeURIComponent(query)}&limit=${limit}` : null,
    fetcher,
    { revalidateOnFocus: false, dedupingInterval: 500 }
  )

  return {
    results: data?.results || [],
    isLoading,
    error,
  }
}

export function useTrendingTools(limit = 10) {
  const { data, error, isLoading } = useSWR<{ trending: TrendingTool[] }>(
    `/api/v1/trending?limit=${limit}`,
    fetcher,
    { revalidateOnFocus: false }
  )

  return {
    trending: data?.trending || [],
    isLoading,
    error,
  }
}

export function useNews(limit = 10) {
  const { data, error, isLoading } = useSWR<{ news: AiNews[] }>(
    `/api/v1/news?limit=${limit}`,
    fetcher,
    { revalidateOnFocus: false }
  )

  return {
    news: data?.news || [],
    isLoading,
    error,
  }
}

export function useUpcomingTools(limit = 10) {
  const { data, error, isLoading } = useSWR<{ upcoming: UpcomingTool[] }>(
    `/api/v1/upcoming?limit=${limit}`,
    fetcher,
    { revalidateOnFocus: false }
  )

  return {
    upcoming: data?.upcoming || [],
    isLoading,
    error,
  }
}
